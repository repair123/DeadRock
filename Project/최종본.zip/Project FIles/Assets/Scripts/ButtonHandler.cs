﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ButtonHandler : MonoBehaviour
{
    public void SetReStart()
    {
        Debug.Log("restart");
        GameManager.instance.ReStartGame();
    }

    public void SetNextStage()
    {
        Debug.Log("next");
        GameManager.instance.NextStage();
    }

    public void SetExit()
    {
        Debug.Log("exit");
        GameManager.instance.Exit();
    }
}
