﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BackgroundMove2 : MonoBehaviour
{
    // Scroll main texture based on time



    void Start() {

    }

    void Update() {

    }
}
