﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Titlemenu : MonoBehaviour
{
    public GameObject title;
    public GameObject info;

    bool infoToggle = false;

    public void playGame() {
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1);
    }

    public void quiteGame() {
        Debug.Log("quit");
        Application.Quit();
    }
    public void showInfoPanel() {
        Debug.Log("INFO");
        title.SetActive(infoToggle);
        info.SetActive(!infoToggle);
        infoToggle = !infoToggle;
    }
}
